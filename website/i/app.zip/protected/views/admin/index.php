<div class="col-sm-12">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="panel-body">
			<?php
			echo $content;
			?>
		</div>
	</div>
</div>