<div class="col-sm-12">
	<?php
	if(Yii::app()->user->hasFlash('notify')) {
		$notify = Yii::app()->user->getFlash('notify');
		?>
		<div class="alert alert-<?php echo $notify['type']; ?>"><?php echo $notify['message']; ?>.</div>
		<?php } ?>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><?php echo Yii::t('servers', 'Серверы'); ?></h3>
			</div>
			<div class="panel-body">
				<?php
				$addLink = CHtml::link('<img src="'.Yii::app()->request->baseUrl.'/images/add-icon.png" style="width:32px;"> '.Yii::t('servers', 'Добавить сервер'), $this->createUrl('admin/serverAdd'));
				if(!empty($servers)) {
					echo $addLink;
					?>
					<table class="table table-striped">
						<thead>
							<th>#</th>
							<th><?php echo Yii::t('servers', 'Комментарий'); ?></th>
							<th><?php echo Yii::t('servers', 'Протокол'); ?></th>
							<th><?php echo Yii::t('servers', 'ip'); ?></th>
							<th><?php echo Yii::t('servers', 'порт'); ?></th>
							<th><?php echo Yii::t('servers', 'веб порт'); ?></th>
							<th><?php echo Yii::t('servers', 'live порт'); ?></th>
						</thead>
						<tbody>
							<?php
							foreach ($servers as $key => $serv) {
								echo '<tr>
								<td>'.($key+1).'</td>
								<td>'.CHtml::encode($serv->comment).'</td>
								<td>'.$serv->protocol.'</td>
								<td>'.$serv->ip.'</td>
								<td>'.$serv->s_port.'</td>
								<td>'.$serv->w_port.'</td>
								<td>'.$serv->l_port.'</td>
								<td>'.CHtml::link(Yii::t('servers', 'Редактировать'), $this->createUrl('admin/serverEdit', array('id' => $serv->id)), array('name' => 'show', 'class' => 'btn btn-primary')).'</td>
								<td>'.CHtml::link(Yii::t('servers', 'Удалить'), $this->createUrl('admin/serverDelete', array('id' => $serv->id)), array('name' => 'del', 'class' => 'btn btn-danger')).'</td>
								<td>'.CHtml::link(Yii::t('servers', 'Статистика'), $this->createUrl('admin/stat', array('type'=> 'disk', 'id' => $serv->id)), array('class' => 'btn btn-warning')).'</td>
								</tr>';
							}
							?>
						</tbody>
					</table>
					<?php
				} else {
					echo Yii::t('servers', '<br/>Список серверов nvr пуст.<br/>');
				}
				echo $addLink;
				?>
			</div>
		</div>
	</div>