<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/fullscreen'); ?>
<div id="content">
	<?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>