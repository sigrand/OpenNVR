<?php echo CHtml::encode(Yii::app()->name); ?>
<?php echo $content ?>