<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/empty'); ?>
	<?php echo $content; ?>
<?php $this->endContent(); ?>