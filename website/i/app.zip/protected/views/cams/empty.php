<?php
/* @var $this CamsController */
echo $content;
?>