<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');
///qqqqqqqqq
// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'{app}',
	'sourceLanguage' => 'ru',
	'behaviors'=>array(
		'onBeginRequest' => array(
			'class' => 'application.components.behaviors.BeginRequest'
			),
		),
	// preloading 'log' component
	'preload'=>array('log'),

	// autoloading model and component classes
	'import'=>array(
		'application.models.*',
		'application.components.*',
		),

	'modules'=>array(
		),

	// application components
	'components'=>array(
		'request'=>array(
			'enableCsrfValidation'=>true,
			'enableCookieValidation'=>true,
			),
		'user'=>array(
			// enable cookie-based authentication
			'allowAutoLogin'=>true,
			),
		// uncomment the following to enable URLs in path-format
		//*
		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
				'/'=>'cams/index',
				'cams/existence/id/<id:\d+>/<stream:\d+|\d+_low>'=>'cams/existence',
				),
			),
		//*/
		'db'=>array(
			'connectionString' => 'mysql:host={h};dbname={d}',
			'emulatePrepare' => true,
			'username' => '{u}',
			'password' => '{p}',
			'charset' => 'utf8',
			),
		//*/
		'errorHandler'=>array(
			// use 'site/error' action to display errors
			'errorAction'=>'site/error',
			),
		'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
					),
				// uncomment the following to show log messages on web pages
				/*
				array(
					'class'=>'CWebLogRoute',
				),
				//*/
			),
			),
		),

	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params'=>array(
	'languages' => 
	array(
		'ru'=>'Russian',
		'en'=>'English',
		'cn'=>'Chinese'
		),
		// this is used in contact page,
		'adminEmail'=>'webmaster@example.com',
		),
	);