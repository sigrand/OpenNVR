<?php

class ShareForm extends CFormModel {
	private $camBuff;
	private $emailBuff;
	public $hcams;
	public $cams;
	public $emails;

	public function rules()	{
		return array(
			array('cams, emails, hcams', 'required', 'message' => Yii::t('errors', 'Не может быть пустым')),
			array('hcams', 'isOwned'),
			);
	}

	public function beforeValidate() {
		if(parent::beforeValidate()) {
			$cams = array_map('trim', explode(',', $this->hcams));
			$c = count($cams);
			foreach ($cams as $cam) {
				$this->camBuff[] = Cams::model()->findByPK(Cams::model()->getRealId($cam));
			}
			$this->camBuff = array_filter($this->camBuff);
			if(empty($this->camBuff) || count($this->camBuff) != $c) {
				$this->addError('cams', $c > 1 ? Yii::t('errors', 'Одна из камер не сушествует') : Yii::t('errors', 'Камера не существует'));
				return false;
			}
			$emails = array_map('trim', explode(',', $this->emails));
			$c = count($emails);
			$this->emailBuff = Users::model()->findAllByAttributes(array('email' => $emails));
			if(empty($this->emailBuff) || count($this->emailBuff) != $c) {
				$this->addError('emails', $c > 1 ? Yii::t('errors', 'Один из пользователей не сушествует') : Yii::t('errors', 'Пользователь не существует'));
				return false;	
			}
			return true;
		}
		return false;
	}

	public function isOwned() {
		if($this->camBuff) {
			$c = count($this->camBuff);
			foreach ($this->camBuff as $cam) {
				if($cam->user_id != Yii::app()->user->getId()) { $this->addError('cams', $c > 1 ? Yii::t('errors', 'Камеры вам не принадлежат.') : Yii::t('errors', 'Камера вам не принадлежит')); return false; }
			}
			return true;
		}
		return false;
	}

	public function save() {
		$id = Yii::app()->user->getId();
		foreach($this->camBuff as $cam) {
			foreach($this->emailBuff as $user) {
				$n = new Notify;
				$shared = Shared::model()->findByAttributes(array('owner_id' => $id, 'user_id' => $user->id, 'cam_id' => $cam->id, 'is_public' => 0));
				if(!$shared) {
					$shared = new Shared;
					$shared->owner_id = $id;
					$shared->user_id = $user->id;
					$shared->cam_id = $cam->id;
					$shared->save();
				}
				$n->note(Yii::t('cams', 'Вам расшарена камера {cam}', array('{cam}' => $cam->name)), array($id, $user->id, $shared->id));
			}
		}
		return true;
	}

	public function attributeLabels() {
		return array(
			'hcams' => Yii::t('cams', 'Камеры, можно неск. разделять ","'),
			'cams' => Yii::t('cams', 'Камеры, можно неск. разделять ","'),
			'emails' => Yii::t('cams', 'Email`ы/Группы, можно неск. разделять ","')
			);
	}

}